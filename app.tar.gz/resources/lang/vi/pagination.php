<?php
return [
    "previous"=> "Trước",
    "next"=> "Sau"

];